<?php $__env->startSection('title', 'Daftar Kontak'); ?>
<?php $__env->startSection('body'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10 mt-5 mb-5">
            <div class="card">
                <div class="card-header ">
                    <h2>Contact List</h2>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-border">
                            <thead class="bg-dark text-white">
                                <tr>
                                    <th>Nama</th>
                                    <th>Email</th>
                                    <th>Telepon</th>
                                    <th>Pesan</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($contact['name']); ?></td>
                                    <td><?php echo e($contact['email']); ?></td>
                                    <td><?php echo e($contact['phone']); ?></td>
                                    <td><?php echo e($contact['message']); ?></td>
                                    <td class="text-center">
                                        <form action="<?php echo e(route('contact.delete', $contact['name'])); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-m">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center">Tidak ada kontak yang tersedia.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelCommerce\resources\views/contactlist.blade.php ENDPATH**/ ?>