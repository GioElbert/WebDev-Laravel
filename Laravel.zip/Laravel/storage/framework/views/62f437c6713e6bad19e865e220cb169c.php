<?php $__env->startSection('title', 'Message'); ?>
<?php $__env->startSection('body'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8 text-center">
            <div class="jumbotron">
                <h1 class="display-4">Thank You!</h1>
                <p class="lead"><?php echo e($message); ?></p>
                <hr class="my-4">
                <p class="lead">
                    <a class="btn btn-primary btn-lg" href="<?php echo e($contactListRoute); ?>" role="button">View Contact List</a>
                    <a class="btn btn-secondary btn-lg" href="<?php echo e($formRoute); ?>" role="button">Return to Form</a>
                </p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("template.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelCommerce\resources\views/success_message.blade.php ENDPATH**/ ?>